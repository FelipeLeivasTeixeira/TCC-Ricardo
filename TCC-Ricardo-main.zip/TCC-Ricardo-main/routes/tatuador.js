var express = require("express");
var router = express.Router();

router.get("/cadastro", function (req, res, next) {
  res.render("cadastroTatuador", { title: "Express" });
});

router.get("/listar", function (req, res, next) {
    res.render("tatuadores", { title: "Express" });
  });
  
module.exports = router;
